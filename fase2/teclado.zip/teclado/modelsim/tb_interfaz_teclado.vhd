--------------------------------------------------------------------------------
-- tb_interfaz_teclado: banco de pruebas para el subsistema de teclado
--
-- Se usa DIV_TEC=4 y TICS_2s=10 para simulacion rapida (no tiempos reales)
--
-- El teclado hexadecimal escanea filas y lee columnas (activo bajo).
-- Para simular una pulsacion hay que:
--   1. Esperar a que fila tenga el valor correcto
--   2. Poner columna activa (a '0' el bit correspondiente)
--   3. Mantenerla varios tics para superar el antirebote
--   4. Soltar (columna <= "1111")
--
-- Casos de prueba:
--   1. Pulsar tecla '5'  (fila=1101, col=1101)
--   2. Pulsar tecla 'A'  (fila=0111, col=1110) -> operacion suma
--   3. Pulsar tecla '0'  (fila=0111, col=1101)
--   4. Pulsar tecla 'B'  (fila=0111, col=1011) -> validar op2
--   5. Pulsar tecla 'C'  (fila=0111, col=0111) -> cambio de signo
--
-- DIV_TEC=49  -> tic cada 50 ciclos de reloj
-- TICS_2s=10 -> pulso largo tras 10 tics
--
-- Para que el antirebote funcione correctamente hay que mantener la columna
-- activa durante al menos 3 tics completos (3 x 50 ciclos = 150 ciclos).
--------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity tb_interfaz_teclado is
end entity;

architecture sim of tb_interfaz_teclado is

    constant T   : time    := 20 ns;  -- 50 MHz
    constant TIC : integer := 50;    -- ciclos por tic

    signal clk           : std_logic := '0';
    signal nRst          : std_logic := '0';
    signal columna       : std_logic_vector(3 downto 0) := "1111";
    signal fila          : std_logic_vector(3 downto 0);
    signal tecla         : std_logic_vector(3 downto 0);
    signal tecla_pulsada : std_logic;
    signal pulso_largo   : std_logic;

begin

    clk  <= not clk after T/2;
    nRst <= '0', '1' after 5*T;

    U_DUT: entity work.interfaz_teclado(estructural)
        generic map(
            DIV_TEC => 49,
            TICS_2s => 10
        )
        port map(
            clk           => clk,
            nRst          => nRst,
            columna       => columna,
            fila          => fila,
            tecla         => tecla,
            tecla_pulsada => tecla_pulsada,
            pulso_largo   => pulso_largo
        );

    process
    begin
        -- Esperar reset y estabilizacion
        wait until nRst = '1';
        for i in 1 to 5*TIC loop
            wait until clk'event and clk = '1';
        end loop;

        -- ----------------------------------------------------------------
        -- CASO 1: tecla '5' -> fila=1101, col=1101
        -- ----------------------------------------------------------------
        report "CASO 1: pulsando tecla 5";
        -- Esperar a que fila = 1101
        loop
            wait until clk'event and clk = '1';
            exit when fila = "1101";
        end loop;
        -- Activar columna
        columna <= "1101";
        -- Mantener pulsada 3*TIC ciclos
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        -- Soltar
        columna <= "1111";
        -- Esperar a que se detecte la pulsacion
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert tecla = X"5"
            report "ERROR caso 1: tecla esperada 5"
            severity error;
        report "OK caso 1: tecla = 5";

        -- ----------------------------------------------------------------
        -- CASO 2: tecla 'A' -> fila=0111, col=1110  (suma)
        -- ----------------------------------------------------------------
        report "CASO 2: pulsando tecla A";
        loop
            wait until clk'event and clk = '1';
            exit when fila = "0111";
        end loop;
        columna <= "1110";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        columna <= "1111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert tecla = X"A"
            report "ERROR caso 2: tecla esperada A"
            severity error;
        report "OK caso 2: tecla = A";

        -- ----------------------------------------------------------------
        -- CASO 3: tecla '0' -> fila=0111, col=1101
        -- ----------------------------------------------------------------
        report "CASO 3: pulsando tecla 0";
        loop
            wait until clk'event and clk = '1';
            exit when fila = "0111";
        end loop;
        columna <= "1101";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        columna <= "1111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert tecla = X"0"
            report "ERROR caso 3: tecla esperada 0"
            severity error;
        report "OK caso 3: tecla = 0";

        -- ----------------------------------------------------------------
        -- CASO 4: tecla 'B' -> fila=0111, col=1011  (validar op2)
        -- ----------------------------------------------------------------
        report "CASO 4: pulsando tecla B";
        loop
            wait until clk'event and clk = '1';
            exit when fila = "0111";
        end loop;
        columna <= "1011";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        columna <= "1111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert tecla = X"B"
            report "ERROR caso 4: tecla esperada B"
            severity error;
        report "OK caso 4: tecla = B";

        -- ----------------------------------------------------------------
        -- CASO 5: tecla 'C' -> fila=0111, col=0111  (cambio signo)
        -- ----------------------------------------------------------------
        report "CASO 5: pulsando tecla C";
        loop
            wait until clk'event and clk = '1';
            exit when fila = "0111";
        end loop;
        columna <= "0111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        columna <= "1111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert tecla = X"C"
            report "ERROR caso 5: tecla esperada C"
            severity error;
        report "OK caso 5: tecla = C";

        -- ----------------------------------------------------------------
        -- CASO 6: pulso largo tecla '1' -> fila=1110, col=1110
        -- Mantener mas de TICS_2s=15 tics -> mas de 15*50=750 ciclos
        -- Se usa 2000 ciclos para asegurar
        -- ----------------------------------------------------------------
        report "CASO 6: pulso largo tecla 1";
        loop
            wait until clk'event and clk = '1';
            exit when fila = "1110";
        end loop;
        columna <= "1110";
        for i in 1 to 15*TIC loop
            wait until clk'event and clk = '1';
        end loop;
        assert pulso_largo = '1'
            report "ERROR caso 6: pulso_largo no detectado"
            severity error;
        report "OK caso 6: pulso_largo detectado";
        columna <= "1111";
        for i in 1 to 3*TIC loop
            wait until clk'event and clk = '1';
        end loop;

        report "tb_interfaz_teclado: SIMULACION COMPLETADA" severity note;
        assert false severity failure;
    end process;

end sim;